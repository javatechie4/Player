package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@Controller
public class PlayerController {

    static List skillList = null;

    static List positionList = null;

    static {
        skillList = new ArrayList<>();
        skillList.add("");
        skillList.add("Defense");
        skillList.add("Attack");
        skillList.add("Speed");
        skillList.add("Strength");
    }

    static {
        positionList = new ArrayList<>();
        positionList.add("");
        positionList.add("Defender");
        positionList.add("Midfielder");
        positionList.add("Forward");

    }

    @Autowired
    Player player;

    @Autowired
    PlayerManager playerManager;

    @Autowired
    Skill skill;

    @GetMapping("/")
    public String home() {
        return "Home";
    }

    @GetMapping("/add")
    public String index(Model model) {
        model.addAttribute("player", new Player());
        model.addAttribute("skillList", skillList);
        model.addAttribute("positionList", positionList);
        return "AddPlayer";
    }

    @RequestMapping(value = "/getBestPlayersView", method = RequestMethod.POST)
    public String addStudent(@ModelAttribute("bestPlayerDTO") BestPlayerDTO bestPlayerDTO,
                             BindingResult bindingResult,
                             Model model,
                             @RequestParam("desiredPosition") String desiredPosition,
                             @RequestParam("desiredSkill") String desiredSkill



    ) {

        if (bindingResult.hasErrors()) {
            return "users/create";
        }
        List<Player> listOfPlayers = playerManager.getBestPlayers(desiredPosition,desiredSkill);

        model.addAttribute("Players", listOfPlayers);

        return "ShowAllPlayers";

    }

    @RequestMapping(value = "/createPlayer", method = RequestMethod.POST)
    public String addStudent(@ModelAttribute("player") Player player,
                             BindingResult bindingResult,
                             Model model,
                             @RequestParam("position") String position,
                             @RequestParam("name") String name,
                             @RequestParam("skillName1") String skillName1,
                             @RequestParam("Value1") String Value1,
                             @RequestParam("skillName2") String skillName2,
                             @RequestParam("Value2") String Value2,
                             @RequestParam("skillName3") String skillName3,
                             @RequestParam("Value3") String Value3,
                             @RequestParam("skillName4") String skillName4,
                             @RequestParam("Value4") String Value4
    ) {

        if (bindingResult.hasErrors()) {
            return "users/create";
        }

        player.setName(name);
        player.setPosition(position);


        if (skillName1!=null && !skillName1.trim().equals("")){
            Skill s1 = new Skill();
            s1.setSkillName(skillName1);
            s1.setValue(Integer.parseInt(Value1));
            player.getSkills().add(s1);
        }

        if (skillName2!=null && !skillName2.trim().equals("")){
            Skill s2 = new Skill();
            s2.setSkillName(skillName2);
            s2.setValue(Integer.parseInt(Value2));
            player.getSkills().add(s2);
        }

        if (skillName3!=null && !skillName3.trim().equals("")){
            Skill s3 = new Skill();
            s3.setSkillName(skillName3);
            s3.setValue(Integer.parseInt(Value3));
            player.getSkills().add(s3);
        }

        if (skillName4!=null && !skillName4.trim().equals("")){
            Skill s4 = new Skill();
            s4.setSkillName(skillName4);
            s4.setValue(Integer.parseInt(Value4));
            player.getSkills().add(s4);
        }

        playerManager.addPlayer(player);

        //return "Home";

        model.addAttribute("Players", playerManager.getPlayers());

        return "ShowAllPlayers";
    }

    @GetMapping("/getBestPlayers")
    public String getBestPlayers(@ModelAttribute("BestPlayerDTO") BestPlayerDTO bestPlayerDTO,
                                 Model model

                                )
    {

        model.addAttribute("BestPlayerDTO", new BestPlayerDTO());
        model.addAttribute("skillList", skillList);
        model.addAttribute("positionList", positionList);
        return "bestPlayer";

    } // end of getBestPlayers

    @GetMapping("/deletePlayer")
    public String deletePlayer(@ModelAttribute("BestPlayerDTO") BestPlayerDTO bestPlayerDTO,
                                 Model model

    )
    {
        model.addAttribute("BestPlayerDTO", new BestPlayerDTO());
        model.addAttribute("Players", playerManager.getPlayers());
        return "deletePlayer";

    } // end of delete player



    @GetMapping(value="/showAllPlayers")
    public String showAllPlayers(Model model) {
        model.addAttribute("Players", playerManager.getPlayers());

        return "ShowAllPlayers";
    }


    @RequestMapping(value = "/deleteByPlayer", method = RequestMethod.POST)
    public String deleteByPlayer(@ModelAttribute("bestPlayerDTO") BestPlayerDTO bestPlayerDTO,
                             BindingResult bindingResult,
                             Model model,
                             @RequestParam("name") String playerName
    ) {

        if (bindingResult.hasErrors()) {
            return "users/create";
        }

        if (playerName!=null){
            playerName = playerName.trim();
        }

        playerManager.deletePlayer(playerName);

        model.addAttribute("Players", playerManager.getPlayers());

        return "ShowAllPlayers";

    } // end of the method

} // end of the class