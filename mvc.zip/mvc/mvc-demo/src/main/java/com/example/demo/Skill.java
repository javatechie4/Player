package com.example.demo;

class Skill {
    private String skillName;
    private int value;

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Skill(String skillName, int value) {
        this.skillName = skillName;
        this.value = value;
    }

    public Skill() {

    }

    public String getSkillName() {
        return skillName;
    }

    public int getValue() {
        return value;
    }
}