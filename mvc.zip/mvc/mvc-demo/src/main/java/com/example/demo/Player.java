package com.example.demo;

import java.util.ArrayList;
import java.util.List;

class Player {
    private String name;

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    private String position;

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    public List<Skill> skills;

    public String getSkillName1() {
        return skillName1;
    }

    public void setSkillName1(String skillName1) {
        this.skillName1 = skillName1;
    }

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

    public String getSkillName2() {
        return skillName2;
    }

    public void setSkillName2(String skillName2) {
        this.skillName2 = skillName2;
    }

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    public String getSkillName3() {
        return skillName3;
    }

    public void setSkillName3(String skillName3) {
        this.skillName3 = skillName3;
    }

    public String getValue3() {
        return value3;
    }

    public void setValue3(String value3) {
        this.value3 = value3;
    }

    String skillName1 = "";
    String value1 = "";

    public String getSkillName4() {
        return skillName4;
    }

    public void setSkillName4(String skillName4) {
        this.skillName4 = skillName4;
    }

    public String getValue4() {
        return value4;
    }

    public void setValue4(String value4) {
        this.value4 = value4;
    }

    String skillName4 = "";
    String value4 = "";

    String skillName2 = "";
    String value2 = "";

    String skillName3 = "";
    String value3 = "";

    public Player(String name, String position, List<Skill> skills) {
        this.name = name;
        this.position = position;
        this.skills = skills;
    }

    public Player(){

    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public List<Skill> getSkills() {
        if (skills==null) {
            skills =new ArrayList<>();
        }
        return skills;
    }
}