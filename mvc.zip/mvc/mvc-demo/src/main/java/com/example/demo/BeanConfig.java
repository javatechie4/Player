package com.example.demo;


import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages="beanconfig")
public class BeanConfig {

    @Bean
    public Player player(){
        return new Player();
    }

    @Bean
    public PlayerManager playerManager(){
        return new PlayerManager();
    }

    @Bean
    @Scope("prototype")
    public Skill skill(){
        return new Skill();
    }

}
