package com.example.demo;

public class Employee {
    public Employee(String john) {
    }
}
