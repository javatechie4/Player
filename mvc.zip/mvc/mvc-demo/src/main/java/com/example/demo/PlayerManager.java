package com.example.demo;

import java.util.*;

class PlayerManager {
    private List<Player> players;

    public PlayerManager() {
        this.players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void deletePlayer(String playerName) {
        players.removeIf(player -> player.getName().equals(playerName));
    }

    public List<Player> getPlayers() {
        return players;
    }

    public List<Player> getBestPlayers(String desiredPosition, String desiredSkill) {
        List<Player> bestPlayers = new ArrayList<>();

        for (Player player : players) {
            if (player.getPosition().equalsIgnoreCase(desiredPosition)) {
                for (Skill skill : player.getSkills()) {
                    if (skill.getSkillName().equalsIgnoreCase(desiredSkill)) {
                        bestPlayers.add(player);
                        break;
                    }
                }
            }
        }

        return bestPlayers;
    }
}