function hello() {
    alert("Hello from Spring MVC");
}


