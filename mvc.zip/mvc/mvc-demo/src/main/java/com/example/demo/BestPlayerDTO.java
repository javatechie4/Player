package com.example.demo;

public class BestPlayerDTO {
    public String getDesiredPosition() {
        return desiredPosition;
    }

    public void setDesiredPosition(String desiredPosition) {
        this.desiredPosition = desiredPosition;
    }

    public String getDesiredSkill() {
        return desiredSkill;
    }

    public void setDesiredSkill(String desiredSkill) {
        this.desiredSkill = desiredSkill;
    }

    String desiredPosition = "";
    String desiredSkill = "";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String name = "";


}
